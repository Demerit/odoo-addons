Controlled Point Of Sale v10
============================

This module will help you to control POS interface.

Depends
=======
[point_of_sale] addon Odoo

Tech
====
* [Python] - Models
* [XML] - Odoo views
* [JS] - static.

Installation
============
- www.odoo.com/documentation/10.0/setup/install.html
- Install our custom addon

Credits
=======
Cybrosys Techno Solutions

Authors
-------
* Sreejith P <https://www.cybrosys.com>
* Aswani PC <https://www.cybrosys.com>
