========================
Disable Database Manager
========================

Installation
============

It is recommended to restart Odoo after the module is installed.

Configuration
=============

Start Odoo with the ``--no-database-list`` CLI parameter or the ``list_db``
configuration parameter set to ``False`` to disable the database management
functions.
