# MuK Document Management System

MuK Documents is a module to create, manage and view files within Odoo.

---

<img align="center" src="static/description/demo.gif"/>
