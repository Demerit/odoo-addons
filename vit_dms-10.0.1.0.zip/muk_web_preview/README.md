# MuK Preview

Adds a button to the FieldBinaryFile form widget to preview the file content directly in the browser.
Currently the following file extensions are supported:

* Portable Document Format (.pdf)
* Open Document (.odt, .odp, .ods, .otp)