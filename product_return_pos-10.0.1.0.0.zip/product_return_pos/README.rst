POS Return v10
==============

Helps You To Manage Product Return From Frontend.

Depends
=======
[point_of_sale] addon Odoo

Installation
============

- www.odoo.com/documentation/10.0/setup/install.html
- Install our custom addon

License
=======
GNU LESSER GENERAL PUBLIC LICENSE, Version 3 (LGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Bug Tracker
===========

Contact odoo@cybrosys.com

Credits
=======
Anusha P P @ cybrosys, anusha@cybrosys.in
Linto CT @ cybrosys, linto@cybrosys.in


Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
