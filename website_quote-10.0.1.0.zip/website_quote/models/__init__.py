# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import sale_order
import sale_quote
import product_template
import ir_model_fields
